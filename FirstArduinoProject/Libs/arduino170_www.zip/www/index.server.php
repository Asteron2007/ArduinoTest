<?php

require_once ("index.common.php");
$xajax->processRequest();

?>
